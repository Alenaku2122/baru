import json,os,datetime,time
from telethon.sync import TelegramClient
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.functions.channels import GetParticipantsRequest, GetFullChannelRequest, InviteToChannelRequest
from telethon.tl.types import InputPeerEmpty, ChannelParticipantsSearch,UserStatusOffline, UserStatusRecently, InputPeerChannel, InputPeerUser
from telethon.errors.rpcerrorlist import PeerFloodError, UserPrivacyRestrictedError

lgr = "\033[90m"
lr = "\033[91m"
lg = "\033[92m"
ly = "\033[93m"
lb = "\033[94m"
lc = "\033[96m"
lx = "\033[0m"

def banner(user=None):
	user = user.get_me().first_name if user else "User"
	banner_text = f"""{lc}
                                         
 █▀▄▀█ █▀█ █░░ █▀█ █▀▄▀█ █▄▄ █▀▀ █▄░█ █▄▀
 █░▀░█ █▀▄ █▄▄ █▄█ █░▀░█ █▄█ ██▄ █░▀█ █░█{ly} V.1
{lgr} By CHAMAEL EBY (DUCER)
{lg} Selamat Datang Bosku!! {ly}{user}{lg} !
{lx}"""
	os.system('clear')
	print(banner_text)
def loading(delay):
	rg = delay
	for i in range(rg):
		try:
			print(f"\r{lgr}    Mohon Di tunggu Bosku!!  ({rg-(i+1)}s){lx}",end="",flush=True)
			time.sleep(1)
		except:
			exit()
	print()
def date_format(message):
	"""
	:param message:
	:return:
	"""
	if type(message) is datetime:
		return message.strftime("%Y-%m-%d %H:%M:%S")
def paginate(data,col=2):
	n_data = round(len(data)/col) + 1
	new_data_part = []
	batas = 0
	for i in range(n_data):
		new_data = []
		for x in range(batas,col+batas):
			try:
				new_data.append(data[x])
			except:
				pass
			batas += 1
		if new_data: new_data_part.append(new_data)
	return new_data_part

def init():
	banner()
	try:
		os.mkdir(".tmp")
	except:
		pass
	try:
		os.mkdir(".users")
	except:
		pass
	try:
		os.mkdir("results")
	except:
		pass

	if not "user.config" in os.listdir(".tmp"):
		json.dump({"phone":None},open(".tmp/user.config","w"))
	phone = json.load(open(".tmp/user.config"))['phone']
	if not phone:
		list_user = os.listdir(".users")
		if not list_user:
			phone = input(f"{lg}[*]{lx} Kita Masuk Nomorta Bosku ( Contoh : +62812..): ")
			while not "+62" in phone:
				print(f'{lr}[*]{lx} Mohon Gunakan Nomor Awalan +62 ')
				phone = input(f"{lg}[*]{lx}Nomorta Gare Bosku ( Contoh :+62812..): ")
		else:
			print(f"{lg}[*]{lx} Anda Sudah Login Di Akun Sebelumnya.\nPilih User")
			for usr in list_user:
				print(f"   {lg}{n}.{lx} {usr}")
				n += 1
			us = input(f"{lg}[*]{lx} Pilih Akun untuk login di akun lainnya: ")
			if us:
				cred = json.load(open(f".users/{list_user[int(us)-1]}"))
				phone = "+"+cred["phone"]
			else:
				phone = input(f"{lg}[*]{lx} Nomorta Gare Bosku ( Contoh :+62812..): ")
				while not "+62" in phone:
					print(f'{lr}[*]{lx} Mohon Gunakan +62 untuk awal nomor')
					phone = input(f"{lg}[*]{lx}Nomorta Gare Bosku ( Contoh :+62812..): ")
	client = login(phone)
	main_menu(client)
def main_menu(client):
	banner(client)
	print(f"""
    Pilih Menu
    
1. Menambahkan Anggota Ke Grup
2. Mendapatkan ID Member Group
3. Menu Akun
4. Reset Robot
5. Exit
""")
	menu = input(f"{lg}[*]{lx} Input Menu : ")
	if menu in ["1","01"]:
		menu_add_members(client)
	elif menu in ["2","02"]:
		get_group_members(client)
	elif menu in ["3","03"]:
		menu_account(client)
	elif menu in ["4","04"]:
		dlt = input("Reset tool ? [y/n]: ")
		if dlt == "y":
			try:
				os.system("rm -rf .tmp")
				os.system("rm -rf .users")
				os.system("rm -rf results")
				os.system("rm  *.session")
			except:
				pass
	else:
		exit()
def menu_account(client):
	user = client.get_me()
	banner(client)
	print("""
1. Current Detail Akun
2. Tambahkan Akun Baru
3. Pindah ke akun lainnya
4. Hapus Akun

Enter to back
""")
	opt = input(f"{lg}[*]{lx} Select Menu : ")
	if opt == "1":
		uid = user.id if user.id else "-"
		ufname = user.first_name if user.first_name else "-"
		ulname = user.last_name if user.last_name else "-"
		uname = "@"+user.username if user.username else "-"
		uphone = "+"+user.phone if user.phone else "-"
		detail = f"""
Your Account Details
{lg}--------------------{lx}

ID           : {uid}
First Name   : {ufname}
Last Name    : {ulname}
Username     : {uname}
Phone Number : {uphone}
"""
		print(detail)
		input("Enter to back ")
		menu_account(client)

	elif opt == "2":
		phone = input(f"{lg}[*]{lx}Nomorta Gare Bosku!! ( Contoh :+62812..): ")
		client = login(phone)
		main_menu(client)
	elif opt == "3":
		n = 1
		list_user = os.listdir(".users")
		if len(list_user) != 0:
			print(f"{lg}[*]{lx} Pilih User")
			for usr in list_user:
				print(f"   {lg}{n}.{lx} {usr}")
				n += 1
			us = input(f"{lg}[*]{lx} Pilih: ")
			if us:
				cred = json.load(open(f".users/{list_user[int(us)-1]}"))
				phone = "+"+cred["phone"]
				if cred["phone"] == user.phone:
					print(f"{ly}[*]{lx} Akun ini sudah login sebelumnya. Pilih akun lainnya untuk Login Kembali")
					exit()
				else:
					client = login(phone)
					main_menu(client)
					
		else:
			print(f"{ly}[*]{lx} Kamu Tidak Memiliki Akun . Login Kembali.")
			exit()
			
	elif opt == "4":
		n = 1
		list_user = os.listdir(".users")
		if len(list_user) != 0:
			print(f"{lg}[*]{lx} Memilih Akun untuk dihapus")
			for usr in list_user:
				print(f"   {lg}{n}.{lx} {usr}")
				n += 1
			us = input(f"{lg}[*]{lx} Pilih: ")
			if us:
				cred = json.load(open(f".users/{list_user[int(us)-1]}"))
				phone = "+"+cred["phone"]
				if cred["phone"] == user.phone:
					dlt = input(f"{ly}[*]{lx} Apakah Benar akun ini ingin di Keluarkan ?. Hapus? [y/n] : ")
					if dlt != "y":
						exit()
				print(f"{lg}[*]{lx} Deleting {cred['first_name']} account..")
				sess = phone + ".session"
				os.remove(sess)
				os.remove(f".users/{list_user[int(us)-1]}")
				os.remove(f".tmp/user.config")
				print(f"{lg}[*]{lx} Done !")
				exit()

		else:
			print(f"{ly}[*]{lx} Kamu tidak memiliki akun . Mohon Login Kembali.")
			exit()
	else:
		main_menu(client)
		
		
def menu_add_members(client):
	banner(client)
	print(f"{lr}NOTE: {lx} Jangan Memberikan File Ini selain Anggota MR LOMBENK From BOSKA!!!!!")
	print(f"{ly}TIPS: {lx} Angkalingaki Baca Bosku From BOSKA!!!!")
	#print(f"\n\n{lg}[*]{lx} Enter limit of add member (max 200/account) or pass to use default limit (50)")
	#limit = input(f"{lg}   > {lx}")
	print(f"{lg}[*]{lx} Masukkan Delay Bosku Maksimal (60)")
	delay = input(f"{lg}   > {lx}")
	if delay:
		print(f"{lg}[*]{lx} Anda Menggunakan Kostum Delay ({delay}s)")
		add_member(client,delay=int(delay))
	#elif limit and not delay:
	#	print(f"{lg}[*]{lx} Use custom limit ({limit} users) and default delay (60s)")
	#	add_member(client,limit=int(limit))
	#elif delay and not limit:
	#	print(f"{lg}[*]{lx} Use default limit (50 users) and custom delay ({delay}s)")
	#	add_member(client,delay=int(delay))
	else:
		print(f"{lg}[*]{lx} Gunakan Default Delay (60s)")
		add_member(client)
		
	

def login(phone=None):
	print(f"{lg}[*]{lx} Tajengi Jolo Bosku!!!")
	api_id = 7522207
	api_hash = 'b6c48d25d198071cb1a510cd1ce6dbc2'
	try:
		client = TelegramClient(phone, api_id, api_hash)
		client.connect()
		if not client.is_user_authorized():
			client.send_code_request(phone)
			client.sign_in(phone, input(f'{lg}[*]{lx} Kasih Masuk Gare Kode Bosku!!!: '))
		json.dump({"phone":phone},open(".tmp/user.config","w"))
		json.dump(client.get_me().to_dict(), open(f".users/{client.get_me().first_name}-{client.get_me().id}.json","w"), default=date_format)
		user = client.get_me()
		user_name = user.first_name
		return client
	except Exception as e:
		print(f"{lr}[*]{lx} Salah Kode ki Bosku : {ly}{e}{lx}")
		
def isActive(user):
	is_active = False
	status = user.status
	if isinstance(status, UserStatusOffline):
		return (datetime.datetime.now(tz=datetime.timezone.utc) - status.was_online) <= datetime.timedelta(days=1)
	elif isinstance(status,UserStatusRecently):
		return True
	else:
		return False
		
def get_group_list(client,add=False):
	chats = []
	last_date = None
	chunk_size = 200
	groups=[]
	result = client(GetDialogsRequest(
				offset_date=last_date,
				offset_id=0,
				offset_peer=InputPeerEmpty(),
				limit=chunk_size,
				hash = 0
				))
	chats.extend(result.chats)
	for chat in chats:
		dik = chat.to_dict()
		# check if chat type is group, not channel
		if "invite_users" in str(dik):
			#print(json.dumps(dik, default=date_format,indent=2))
			if add:
				if dik["admin_rights"]:
					groups.append(chat)
			else:
				if not dik["admin_rights"]:
					groups.append(chat)
	if len(groups) != 0:
		index = 1
		print(f"{lg}[*] {lx}List Grup\n")
		for i in groups:
			print(f"    {lg}{index}.{lx} {i.title} ({ly}{i.participants_count} {lx}members)")
			index +=1
		sl = input(f"\n{lg}[*] {lx}Pilih Grup: ")
		if not sl:
			main_menu(client)
		else:
			sltd = groups[int(sl) - 1]
			return sltd
	else:
		if add:
			print(f"{ly}[*]{lx} Tidak Bisaki Menambahkan Anggota \nKarena ini Nomor Bukan Admin Group Kasih Jadi Admin Dulu bosku")
		else:
			print(f"{ly}[*]{lx} Tidak Bisaki Menambahkan Anggota.\nMohon Join Grup Dulu bosku dan Jalankan Kembali")
		exit()
			
def get_group_members(client):
	sltd = get_group_list(client)
	print(f"{lg}[*]{lx} Hasil Robot {ly}{sltd.title}{lx} Member Yang Aktif {lc}{sltd.participants_count}{lx} Total Member")
	members = []
	all_members = client.get_participants(sltd, aggressive=True)
	for member in all_members:
		u_id = member.id
		u_hash = member.access_hash
		f_name = member.first_name if member.first_name else ""
		l_name = member.last_name if member.last_name else ""
		u_name = member.username if member.username else ""
		u_phone = member.phone if member.phone else ""
		data = {
				"first_name":f_name,
				"last_name":l_name,
				"username":u_name,
				"id":u_id,
				"hash":u_hash,
				"phone":u_phone
				}
		if isActive(member):
			members.append(data)
			print(f"\r{lg}[*] {lx}Hasil Robot Member Yang Aktif: {ly}{round((len(members)/sltd.participants_count) * 100,2)}%{lx}..",end="",flush=True)
	print(f"\n{lg}[*] {ly}{round((len(members)/sltd.participants_count) * 100,2)}%{lx} ({lc}{len(members)}{lx})Member Yang Aktif Sudah di Simpan Boosku")
	sv = input(f"{lg}[*]{lx}Harap Pilih Huruf 'D' (members-{sltd.title}.json) or custom ? [d/c]: ")
	if sv.upper() == "D":
		fname = f"members-{sltd.title}.json"
	else:
		fname = input(f"{lg}[*]{lx} Enter file name (ex: myid.json) : ")
	print(f"{lg}[*]{lx} Saving result as \"{ly}results/{fname}{lx}\"..")
	json.dump({"amounts":len(members),"data":members},open(f"results/{fname}","w"),indent=2)
	print(f"{lg}[*]{lx} Done!\nFile saved as {ly}{fname}{lx}")
	exit()

def add_member(client,limit=50,delay=60):
	print(f"{lg}[*]{lx} Pilih grup untuk menambahkan member")
	selected_group = get_group_list(client,add=True)
	target_group = InputPeerChannel(selected_group.id,selected_group.access_hash)
	if os.listdir("results"):
		print(f"{lg}[*]{lx} Pilih Id Member File")
		index = 1
		for i in os.listdir("results"):
			print(f"    {lg}{index}.{lx} {i}")
			index += 1
		sltd_id = json.load(open("results/"+os.listdir("results")[int(input(f"{lg}[*]{lx} Pilih: ")) -1]))
		print(f"{lg}[*]{lx} {ly}{len(sltd_id['data'])}{lx} ID loaded !")
		n = 1
		member_part = paginate(sltd_id["data"],50)
		"""
		indx = 1
		start = 1
		print(f"{lg}[*]{lx} Select index of ID from ID list")
		for data in member_part:
			number = f"{lg}{format(indx,str(len(str(len(member_part)))))}. {lx}"
			print(number,end="")
			indx += 1
			part = f"{format(start,str(len(str(len(sltd_id['data'])))))} {ly}-{lx} {start + len(data) - 1}"
			start += len(data)
			print(part)
		print()
		slx = input(f"{lg}[*]{lx} Select index: ")
		slxtd = member_part[int(slx)-1]
		"""
		print(f"{lg}[*]{lx} Input index (ex: 100-200)")
		idx = input(f"{lg}[*]{lx} Input: ")
		start,end = idx.split("-")
		slxtd = sltd_id["data"][int(start)-1:int(end)-1]
		print(f"{lg}[*]{lx} {len(slxtd)} IDs selected")
		print(f"{lg}[*]{lx} Starting !")
		for user in slxtd:
			try:
				user_to_add = InputPeerUser(user['id'], user['hash'])
				print(f'  {lg}{n}.{lx} Add {lc}{user["first_name"]} {user["last_name"]}{lx} to {lc}{selected_group.title}{lx}..')
				n += 1
				client(InviteToChannelRequest(target_group,[user_to_add]))
				loading(delay)
			except UserPrivacyRestrictedError:
				print(f"    {lr}!{lx} Awwweee Ndoe , Privasi Lalo si Na runtu bosku , Sabbaraki Tania Dalle :))")
				continue
			except Exception as e:
				print(f"    {lr}!{lx} Awwwe Erorr Sih Cia Dui : {ly}{e}{lx}")
				continue
	else:
		print(f"{ly}[*]{lx} Depi Je Gaga Id List bosku !!")
		get_group_members(client)
		add_member(client)
init()


